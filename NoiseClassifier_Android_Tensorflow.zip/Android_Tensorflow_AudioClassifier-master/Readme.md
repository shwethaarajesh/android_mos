Android app that helps in music classification based on Tensorflow models with the application of MFCC processing techniques.

Refer this blog for the detailed overview:

https://heartbeat.fritz.ai/noise-classification-in-android-mobile-app-with-tensorflow-lite-13dede0f5d44
