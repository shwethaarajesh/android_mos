package com.tensorflow.android.audio.features;

public class WavFileException extends Exception {

    public WavFileException(final String message) {
        super(message);
    }
}